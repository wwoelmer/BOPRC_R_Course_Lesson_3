# gg.layers 0.1.2

- fix `st_hatched_polygon` for `MULTIPOLYGON`
- reduce R cmd check warnings

# gg.layers 0.1.0

* Added a `NEWS.md` file to track changes to the package.

* `geom_richtext_npc` required_aes change to `x, y, label`
